// All the library-side API for SDE is implemented as a C header,
// so FORTRAN libraries need a phony C file that includes
// the header.
#include "sde_lib.h"
