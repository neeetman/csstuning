Sample: BlackScholes
Minimum spec: SM 3.0

This sample evaluates fair call and put prices for a given set of European options by Black-Scholes formula.

Key concepts:
Computational Finance
