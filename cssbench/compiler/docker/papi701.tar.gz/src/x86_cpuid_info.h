int _x86_cache_info(PAPI_mh_info_t * mh_info);
int _x86_detect_hypervisor(char *vendor_name);




