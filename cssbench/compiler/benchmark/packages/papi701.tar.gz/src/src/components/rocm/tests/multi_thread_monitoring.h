/**
 * @file   multi_thread.h
 * @author Giuseppe Congiu
 *         gcongiu@icl.utk.edu
 *
 */
#ifndef __MULTI_THREAD_H__
#define __MULTI_THREAD_H__

#include "common.h"

int multi_thread(int argc, char *argv[]);

#endif /* End of __MULTI_THREAD_H__ */
